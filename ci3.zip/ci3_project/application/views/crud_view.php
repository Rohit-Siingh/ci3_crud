<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Crud Operation </title>
    <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/css/bootstrap.min.css">

</head>
<body>
    <div class="jumbotron">
    <h1 align="center" style="color:lightblue; line-height:0.8;" >CI CRUD</h1>
    </div>

    <div class="container">
        <div class="clear-fix">
            <h3 style="float: left">All Customer</h3>
            <a href="#" class="btn btn-primary" style="float:right" data-bs-toggle="modal" data-bs-target="#exampleModal">Add Customer</a>
        </div>
        <table class="table table-striped table-hover">
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Mobile No</th>
                    <th>DOB</th>
                    <th>City</th>
                    <th>Country</th>
                    <th>Addresses</th>
                    <th>Landmark</th>
                    <th>State</th>
                    <th>Pincode</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
           <?php foreach($customer_details as $products): ?>

            <tr>
                <td><?php echo $products->name; ?></td>
                <td><?php echo $products->email; ?></td>
                <td><?php echo $products->mobile_no; ?></td>
                <td><?php echo $products->dob; ?></td>
                <td><?php echo $products->city; ?></td>
                <td><?php echo $products->country; ?></td>
                <td><?php echo $products->addresses; ?></td>
                <td><?php echo $products->landmark; ?></td>
                <td><?php echo $products->state; ?></td>
                <td><?php echo $products->pincode; ?></td>
                <td>
                    <a href="<?php echo base_url();?>Crud/editCustomer/<?php echo $products->id;?>" class="btn btn-success">Edit</a>
                    <a href="<?php echo base_url();?>Crud/deleteCustomer/<?php echo $products->id?>" class="btn btn-danger">Delete</a>
                </td>

            </tr>
            <?php endforeach;?>
            <tbody>
        </table>
    </div>
    
    




    <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <form action="<?php echo base_url();?>Crud/addCustomer" method="post">
       
      <div class="modal-header">
          <h5 class="modal-title">Add Customer</h5>
      </div>
      
        <div class="modal-body">
         
          <div class="row g-3">
          <div class="col-md-6">
          <div class="form-group">
            <label for="name">Name</label>
            <input type="text" name="name" id="name" class="form-control" style="text-transform: capitalize;"required>
          </div>
          </div>
          <div class="col-md-6">

          <div class="form-group">
            <label for="email">Email</label>
            <input type="email" name="email" id="email" class="form-control" required>
          </div>
          </div>
          </div>
          <div class="row g-3">
          <div class="col-md-6">
          <div class="form-group">
            <label for="mobile_no">Mobile No</label>
            <input type="text" name="mobile_no" id="mobile_no" class="form-control" onkeypress="return event.charCode>=48 && event.charCode<=57 " maxlength="10" required>
          </div>
          </div>
          <div class="col-md-6">
          <div class="form-group">
            <label for="dob">DOB</label>
            <input type="date" name="dob" id="dob" class="form-control" required>
          </div>
          </div>
          </div>

         
        
          <div class="modal-header">
          <h5 class="modal-title">Add address</h5>
          </div>

          <div class="row g-3">
          <div class="col-md-6">
          <div class="form-group">
            <label for="addresses">Address</label>
            <input type="text" name="addresses" id="addresses" class="form-control" required>
         </div>
          </div>

          <div class="col-md-6">
         <div class="form-group">
            <label for="landmark">Landmark</label>
            <input type="text" name="landmark" id="landmark" class="form-control" required>
         </div>
          </div>
          </div>

          <div class="row g-3">
          <div class="col-md-6">
         <div class="form-group">
            <label for="state">State</label>
            <input type="text" name="state" id="state" class="form-control" style="text-transform:capitalize;" required>
         </div>
          </div>
          <div class="col-md-6">
         <div class="form-group">
            <label for="pincode">Pincode</label>
            <input type="text" name="pincode" id="pincode" class="form-control" maxlength="6" onkeypress="return event.charCode>=48 && event.charCode<=57" required>
         </div>
          </div>
          </div>
       
          <div class="row g-3">
          <div class="col-md-6">
          <div class="form-group">
            <label for="city">City</label>
            <input type="city" name="city" id="city" class="form-control" onkeypress="return event.charCode>=65 && event.charCode<=122 || event.charCode==32" style="text-transform:capitalize;" required>
          </div>
          </div>
          <div class="col-md-6">
          <div class="form-group">
            <label for="country">Country</label>
            <input type="country" name="country" id="country" class="form-control" onkeypress="return event.charCode>=65 && event.charCode<=122 || event.charCode==32" style="text-transform:capitalize;" required>
          </div>
          </div>
          </div>
        
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
          <input type="submit" name="insert" value="Add Product" class="btn btn-info">
        </div>
      </form>
      </div>

    </div>
  </div>
</div>

<?php foreach ($departments as $dept): ?>
<div class="modal fade" id="departmentModal_<?php echo $dept->department_id; ?>" tabindex="-1" aria-labelledby="departmentModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Department Details</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <p><strong>Department ID:</strong> <?php echo $dept->department_id; ?></p>
                <p><strong>Department Name:</strong> <?php echo $dept->department_name; ?></p>
            </div>
        </div>
    </div>
</div>
<?php endforeach; ?>


<?php if($this->session->flashdata('error')): ?>
<div class="alert alert-success text-center" style="position: fixed; top: 0; width: 100%;">
<?php echo $this->session->flashdata('error')?>
</div>
<?php endif; ?>

<?php if($this->session->flashdata('inserted')): ?>
<div class="alert alert-success text-center" style="position: fixed; top: 0; width: 100%;">
<?php echo $this->session->flashdata('inserted')?>
</div>
<?php endif; ?>

<?php if($this->session->flashdata('updated')): ?>
<div class="alert alert-success text-center" style="position: fixed; top: 0; width: 100%; ">
<?php echo $this->session->flashdata('updated')?>
</div>
<?php endif; ?>

<?php if($this->session->flashdata('deleted')): ?>
<div class="alert alert-success text-center" style="position: fixed; top: 0; width: 100%">
<?php echo $this->session->flashdata('deleted')?>
</div>
<?php endif; ?>

<script>
    setTimeout(function(){
      let message=document.querySelectorAll('.alert');
      message.forEach(function(msg){
        msg.style.display='none';
      })
    },2000)
   
        
</script>
  <!---->

<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.min.js" integrity="sha384-0pUGZvbkm6XF6gxjEnlmuGrJXVbNuzT9qBBavbLwCsOGabYfZo0T0to5eqruptLy" crossorigin="anonymous"></script></body>
</html>