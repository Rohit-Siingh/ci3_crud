

    <?php
    defined('BASEPATH') OR exit('No direct script access allowed');
  

    class Crud extends CI_Controller {
      
    public function __construct() {
    parent::__construct();
    $this->load->model('Crud_model');
    $this->load->library('form_validation');
}
        public function index(){
         
        $data['customer_details']=$this->Crud_model->getAllCustomer();
        $this->load->view('crud_view',$data);
         
    }       
    
    public function addCustomer() {
        $this->load->model('Crud_model'); 
    
        $this->form_validation->set_rules('name', 'Name', 'trim|required');
        $this->form_validation->set_rules('email', 'Email', 'trim|required|valid_email');
        $this->form_validation->set_rules('mobile_no', 'Mobile no', 'trim|required');
        $this->form_validation->set_rules('dob', 'DOB', 'trim|required');
        $this->form_validation->set_rules('city', 'City', 'trim|required');
        $this->form_validation->set_rules('country', 'Country', 'trim|required');
        $this->form_validation->set_rules('addresses', 'Address', 'trim|required');
        $this->form_validation->set_rules('landmark', 'Landmark', 'trim|required');
        $this->form_validation->set_rules('state', 'State', 'trim|required');
        $this->form_validation->set_rules('pincode', 'Pincode', 'trim|required|integer');
    
        if ($this->form_validation->run() == false) {
            $this->session->set_flashdata('error', validation_errors());
        } else {
            $productData = [
                'name' => ucwords($this->input->post('name', true)),
                'email' => strtolower($this->input->post('email', true)),
                'mobile_no' => $this->input->post('mobile_no'),
                'dob' => $this->input->post('dob'),
                'city' => ucwords($this->input->post('city', true)),
                'country' => ucwords($this->input->post('country', true))
            ];
    
            $this->db->insert('Products', $productData);
            $address_id = $this->db->insert_id();  
    
            if ($address_id) {
                $addressData = [
                    'address_id' => $address_id,
                    'addresses' => $this->input->post('addresses', true),
                    'landmark' => $this->input->post('landmark', true),
                    'state' => $this->input->post('state', true),
                    'pincode' => $this->input->post('pincode', true)
                    
                ];
    
                
                if (method_exists($this->Crud_model, 'insertAddress')) {
                    $this->Crud_model->insertAddress($addressData);
                    $this->session->set_flashdata('inserted', 'Your data and order saved successfully');
                } else {
                    log_message('error', 'inserAddress method not found in Crud_model');
                }
            }
        }
        redirect('Crud');
    }
    
    
   
        public function editCustomer($id){
            $data['singleProduct']=$this->Crud_model->getSingleCustomer($id);
            $this->load->view('editView',$data);
        }
        public function update($id){
            $this->form_validation->set_rules('name','Name','trim|required');
            $this->form_validation->set_rules('email','Email','trim|required|valid_email');
            $this->form_validation->set_rules('mobile_no','Mobile_no','trim|required');
            $this->form_validation->set_rules('dob','DOB','trim|required');
            $this->form_validation->set_rules('city','City','trim|required');
            $this->form_validation->set_rules('country','Country','trim|required');
           
        if($this->form_validation->run()==false){
            $this->session->set_flashdata('error',validation_errors());
        }
        else{
           $data=$this->Crud_model->updateCustomer([
                'name'=>ucwords($this->input->post('name',true)),
                'email'=>strtolower($this->input->post('email',true)),
                'mobile_no'=>$this->input->post('mobile_no'),
                'dob'=>$this->input->post('dob'),
                'city'=>ucwords($this->input->post('city',true)),
                'country'=>ucwords($this->input->post('country',true))
            ], $id);
            if($data){
                $this->session->set_flashdata('updated','your data updated successfully');
            }
        }
        redirect('Crud');
        }

        public function deleteCustomer($id){
            $result=$this->Crud_model->deleteCustomer($id);
        if($result==true){
            $this->session->set_flashdata('deleted','the product has been deleted');
        }
        redirect('Crud');
        }
    } 
    ?>
    


