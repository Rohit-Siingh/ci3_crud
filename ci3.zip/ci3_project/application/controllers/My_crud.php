<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class My_crud extends CI_Controller{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('My_crud_model');
        $this->load->library('form_validation');
    }

    public function index(){
        $data['emp_details']=$this->My_crud_model->getAllEmployee();
        $this->load->view('my_crud_view',$data);
    }

public function addEmployee(){
    
    $this->load->model('My_crud_model'); 
    
    $this->form_validation->set_rules('full_name', 'Full Name', 'trim|required');
    $this->form_validation->set_rules('email', 'Email', 'trim|required|valid_email');
    $this->form_validation->set_rules('phone_no', 'Phone no', 'trim|required');
    $this->form_validation->set_rules('dob', 'DOB', 'trim|required');
    $this->form_validation->set_rules('gender', 'Gender', 'trim|required');
    $this->form_validation->set_rules('designation', 'Designation', 'trim|required');
    $this->form_validation->set_rules('salary', 'Salary', 'trim|required');
    $this->form_validation->set_rules('join_date', 'Join Date', 'trim|required');
    $this->form_validation->set_rules('status', 'Status', 'trim|required');
    $this->form_validation->set_rules('profile_pic', 'Profile Pic', 'trim|required');
    $this->form_validation->set_rules('hobbies', 'Hobbies', 'trim|required');
    $this->form_validation->set_rules('achievements', 'Achievements', 'trim|required');
    $this->form_validation->set_rules('department_name', 'Department Name', 'trim|required');


    if ($this->form_validation->run() == false) {
        $this->session->set_flashdata('error', validation_errors());
    } else {
        $employeeData = [
            'full_name' => ucwords($this->input->post('full_name', true)),
            'email' => strtolower($this->input->post('email', true)),
            'phone_no' => $this->input->post('phone_no',true),
            'dob' => $this->input->post('dob'),
            'gender' => $this->input->post('gender', true),
            'designation' => $this->input->post('designation', true),
            'salary' => $this->input->post('salary', true),
            'join_date' => $this->input->post('join_date', true),
            'status' => $this->input->post('status', true),
            'profile_pic' => $this->input->post('profile_pic', true),
            'hobbies' => $this->input->post('hobbies', true),
            'achievements' => $this->input->post('achievements', true)
            
        ];

       
        $departmentData = [
            'department_name' => $this->input->post('department_name', true)
                ];
                  
                // if (method_exists($this->My_crud_model, 'insertDepartment')) {
                    // echo 112332;die;
                    $departmentId=$this->My_crud_model->insertDepartment($departmentData);
                //     $this->session->set_flashdata('inserted', 'Your data and order saved successfully');
                // } else {
                //     log_message('error', 'insertDepartment method not found in Crud_model');
                // }   
                // print_r($kasdgas);die;

                $employeeDataa = [
                    'department_id'=>$departmentId
                ];
                $abc=array_merge($employeeData,$employeeDataa);
                $this->db->insert('employees', $abc);
                $userId = $this->db->insert_id();  
                print_r($userId);die;
            //         if ($department_id) {
            // }
    }
    redirect('My_crud');
}



}


?>