<?php
class Crud_model extends CI_Model{
    public function getAllCustomer(){
        $this->db->order_by('Products.id','DESC');
        $this->db->where('Products.status',1);
        $this->db->select(['Products.*','address.addresses','address.landmark','address.state','address.pincode']);
        $this->db->from('Products');
        $this->db->join('address', 'address.address_id = Products.id', 'left');
        $query=$this->db->get();
        if($query){
            return $query->result();
        }else{
            log_message('error','Database query failed'.$this->db->last_query());
        }
    }

    
    public function insertAddress($data) {
        $query = $this->db->insert('address', $data);
        if ($query) {
            return true;
        } else {
            log_message('error', 'Insert into Address failed: ' . $this->db->last_query());
            return false;
        }
    }
    
    public function insertCustomer($data){
        $query=$this->db->insert('Products',$data);
        

        if($query){
            return true;
        }
        else{
            log_message('error','Insert failed'.$this->db->last_query());
            return false;
        }
    }
    public function getSingleCustomer($id){
        $this->db->where('id',$id);
        $query=$this->db->get('Products');
        if($query)
        {
            return $query->row();
        }
    }
    
    public function updateCustomer($data, $id){
        $this->db->where('id',$id);
        $query=$this->db->update('Products',$data);
        if($query){
            return true;
        }else{
            return false;
        }
    }
    public function deleteCustomer($id){
        $this->db->where('id',$id);
        $query=$this->db->update('Products',['status'=>0]);
        if($query){
            return true;
        }else{
            return false;
        }
    }
}

?>
