<?php
class My_crud_model extends CI_Model{
    public function getAllEmployee(){
       
        $query=$this->db->get('employees');
       
        if($query){
            return $query->result();
        }else{
            log_message('error','database query failed'.$this->db->last_query());
        }
    }
  
   
    public function insertDepartment($data) {
        $query = $this->db->insert('departments', $data);
        if ($query) {
            return $this->db->insert_id();
        } else {
            log_message('error', 'Insert into Address failed: ' . $this->db->last_query());
            return false;
        }
    }


}
?>